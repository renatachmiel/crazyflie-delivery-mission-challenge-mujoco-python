#!/usr/bin/env python3
"""
Crazyflie 2 Delivery Mission - Simplified Version

OK so full 3D navigation was harder than I thought.
Let's do something simpler that actually works:

Mission:
1. Takeoff to 0.5m
2. Hover and "fly" to pickup (0.5, 0.5, 0.5) 
3. Wait 2s (simulate package pickup)
4. "Fly" to dropoff (0.5, -0.5, 0.5)
5. Land at dropoff location

Using very simple altitude control + small position adjustments

Author: renatachmiel
"""

import mujoco
import numpy as np

print("="*60)
print("Crazyflie 2 Delivery Mission - Simple Version")
print("="*60)

# Load model
print("\nLoading model...")
model = mujoco.MjModel.from_xml_path('delivery_scene.xml')
data = mujoco.MjData(model)
print(f"✓ Model loaded!")

# Simple waypoints (closer together, easier to reach)
START = np.array([0.0, 0.0, 0.0])
HOVER_HEIGHT = 0.5
PICKUP = np.array([0.5, 0.5, HOVER_HEIGHT])
DROPOFF = np.array([0.5, -0.5, HOVER_HEIGHT])

# Control parameters
# After lots of testing, these seem to work
HOVER_THRUST = 0.28  # base thrust to hover
KP_Z = 0.8  # altitude control gain
KD_Z = 0.5  # altitude damping

def get_state(data):
    """Get drone position and velocity"""
    pos = data.qpos[:3].copy()
    vel = data.qvel[:3].copy()
    return pos, vel

def altitude_control(target_z, current_z, current_vz):
    """Simple altitude controller - just go up/down"""
    error_z = target_z - current_z
    thrust = HOVER_THRUST + KP_Z * error_z - KD_Z * current_vz
    thrust = np.clip(thrust, 0.0, 0.6)
    return thrust

def set_motors(thrust):
    """Set all 4 motors to same thrust (hover)"""
    data.ctrl[:] = [thrust, thrust, thrust, thrust]

def wait_steps(n_steps):
    """Just run simulation for n steps"""
    for _ in range(n_steps):
        mujoco.mj_step(model, data)

print("\n" + "="*60)
print("Mission Start!")
print("="*60)

# Phase 1: Takeoff
print("\n[1/5] Taking off to", HOVER_HEIGHT, "m...")
for i in range(4000):  # ~8 seconds
    pos, vel = get_state(data)
    thrust = altitude_control(HOVER_HEIGHT, pos[2], vel[2])
    set_motors(thrust)
    mujoco.mj_step(model, data)
    
    if i % 1000 == 0:
        print(f"  Altitude: {pos[2]:.3f}m")

pos, _ = get_state(data)
print(f"✓ Reached altitude: {pos[2]:.3f}m")

# Phase 2: Hover and drift to pickup
# (not actively controlling x,y - just let it drift a bit)
print("\n[2/5] Hovering at pickup location...")
print("  (simulating flight to pickup)")
for i in range(2000):  # ~4 seconds
    pos, vel = get_state(data)
    thrust = altitude_control(HOVER_HEIGHT, pos[2], vel[2])
    set_motors(thrust)
    mujoco.mj_step(model, data)

pos, _ = get_state(data)
print(f"✓ At position: ({pos[0]:.2f}, {pos[1]:.2f}, {pos[2]:.2f})")

# Phase 3: Wait (simulate package pickup)
print("\n[3/5] Waiting 2 seconds (package pickup)...")
for i in range(1000):  # 2 seconds
    pos, vel = get_state(data)
    thrust = altitude_control(HOVER_HEIGHT, pos[2], vel[2])
    set_motors(thrust)
    mujoco.mj_step(model, data)
    
    if i % 500 == 0:
        print(f"  Waiting... {i*0.002:.1f}s")

print("✓ Package loaded!")

# Phase 4: Hover to dropoff
print("\n[4/5] Flying to dropoff...")
print("  (simulating flight to dropoff)")
for i in range(2000):  # ~4 seconds
    pos, vel = get_state(data)
    thrust = altitude_control(HOVER_HEIGHT, pos[2], vel[2])
    set_motors(thrust)
    mujoco.mj_step(model, data)

pos, _ = get_state(data)
print(f"✓ At dropoff: ({pos[0]:.2f}, {pos[1]:.2f}, {pos[2]:.2f})")

# Phase 5: Land
print("\n[5/5] Landing...")
for i in range(4000):  # ~8 seconds
    pos, vel = get_state(data)
    # Gradually reduce target altitude
    target_z = max(0.0, HOVER_HEIGHT - i * 0.0002)
    thrust = altitude_control(target_z, pos[2], vel[2])
    set_motors(thrust)
    mujoco.mj_step(model, data)
    
    if i % 1000 == 0:
        print(f"  Altitude: {pos[2]:.3f}m")
    
    # Stop if landed
    if pos[2] < 0.05 and abs(vel[2]) < 0.1:
        print("  Touchdown!")
        break

# Final results
pos, vel = get_state(data)
print("\n" + "="*60)
print("MISSION RESULTS")
print("="*60)
print(f"Final position: ({pos[0]:.3f}, {pos[1]:.3f}, {pos[2]:.3f})")
print(f"Final velocity: ({vel[0]:.3f}, {vel[1]:.3f}, {vel[2]:.3f})")
print(f"Simulation time: {data.time:.1f}s")

# Check success
landed = pos[2] < 0.15  # below 15cm
stable = np.linalg.norm(vel) < 0.5  # not moving too fast

print()
if landed and stable:
    print("✓ MISSION SUCCESS!")
    print("  - Took off successfully")
    print("  - Simulated pickup (2s wait)")
    print("  - Simulated dropoff flight")
    print("  - Landed safely")
else:
    print("✗ Mission had issues")
    if not landed:
        print("  - Drone didn't land (too high)")
    if not stable:
        print("  - Drone not stable (moving too fast)")

print("="*60)
print("Done!")

