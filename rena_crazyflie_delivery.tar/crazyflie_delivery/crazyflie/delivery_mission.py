#!/usr/bin/env python3
"""
Crazyflie 2 Delivery Mission

Task:
- Takeoff from start (0, 0, 0)
- Fly to pickup at (1, 1, 0.8)
- Wait 2 seconds
- Fly to dropoff at (-1, 1, 0.8)
- Land safely

Using simple PID control for position - nothing fancy!

Author: renatachmiel
Date: Oct 2025
"""

import mujoco
import numpy as np

print("="*60)
print("Crazyflie 2 Delivery Mission")
print("="*60)

# Load model
print("\nLoading model...")
model = mujoco.MjModel.from_xml_path('delivery_scene.xml')
data = mujoco.MjData(model)
print(f"✓ Model loaded: {model.nu} actuators (4 motors)")

# Waypoints for the mission
START_POS = np.array([0.0, 0.0, 0.0])
PICKUP_POS = np.array([1.0, 1.0, 0.8])
DROPOFF_POS = np.array([-1.0, 1.0, 0.8])
LAND_POS = np.array([-1.0, 1.0, 0.0])

# PID gains (found through trial and error)
# OK so the first values were WAY too high lol
# drone was going crazy. these are more reasonable:
KP_POS = 0.5   # position proportional gain (reduced!)
KD_POS = 0.8   # position derivative gain
KP_YAW = 0.2   # yaw proportional gain

# Hover thrust - need this to counteract gravity
# after some testing, this seems about right
HOVER_THRUST = 0.25

def get_drone_state(data):
    """Get current position and velocity of drone"""
    # Drone is body index 1 (0 is world)
    pos = data.qpos[:3].copy()  # x, y, z position
    vel = data.qvel[:3].copy()  # x, y, z velocity
    return pos, vel

def simple_position_control(target_pos, current_pos, current_vel):
    """
    Simple PD controller for position
    Returns thrust commands for 4 motors
    
    OK so after the drone flew away, I realized my motor mixing was wrong.
    Simplified it to just control altitude for now.
    """
    # Position error
    pos_error = target_pos - current_pos
    
    # PD control
    force = KP_POS * pos_error - KD_POS * current_vel
    
    # For now, just control altitude and let horizontal drift
    # Real drone control needs proper attitude control but this is simpler
    thrust_z = HOVER_THRUST + force[2] * 0.1  # vertical thrust
    
    # Add small horizontal corrections
    # (very simplified, not physically accurate but works in sim)
    tilt_x = np.clip(force[0] * 0.05, -0.1, 0.1)
    tilt_y = np.clip(force[1] * 0.05, -0.1, 0.1)
    
    # Map to 4 motors
    # Just using thrust_z for all motors with small tilts
    motor0 = thrust_z + tilt_x - tilt_y
    motor1 = thrust_z - tilt_x + tilt_y
    motor2 = thrust_z + tilt_x + tilt_y
    motor3 = thrust_z - tilt_x - tilt_y
    
    # Clamp to reasonable range
    motors = np.array([motor0, motor1, motor2, motor3])
    motors = np.clip(motors, 0.0, 0.6)  # limit max thrust
    
    return motors

def fly_to_waypoint(target, duration=5.0, tolerance=0.15):
    """Fly to a waypoint and wait until close enough"""
    print(f"  Flying to ({target[0]:.1f}, {target[1]:.1f}, {target[2]:.1f})...")
    
    steps = int(duration / model.opt.timestep)
    
    for i in range(steps):
        pos, vel = get_drone_state(data)
        
        # Calculate motor commands
        motors = simple_position_control(target, pos, vel)
        data.ctrl[:] = motors
        
        # Step simulation
        mujoco.mj_step(model, data)
        
        # Check if reached target
        distance = np.linalg.norm(pos - target)
        if distance < tolerance:
            if i % 500 == 0:
                print(f"    Reached! Distance: {distance:.3f}m")
            return True
        
        if i % 1000 == 0:
            print(f"    Distance: {distance:.3f}m")
    
    # Didn't reach in time
    pos, _ = get_drone_state(data)
    distance = np.linalg.norm(pos - target)
    print(f"    Timeout. Final distance: {distance:.3f}m")
    return distance < tolerance * 2  # allow some slack

def hover(duration=2.0):
    """Hover in place for specified duration"""
    print(f"  Hovering for {duration}s...")
    pos, _ = get_drone_state(data)
    target = pos.copy()
    
    steps = int(duration / model.opt.timestep)
    for i in range(steps):
        pos, vel = get_drone_state(data)
        motors = simple_position_control(target, pos, vel)
        data.ctrl[:] = motors
        mujoco.mj_step(model, data)
        
        if i % 500 == 0:
            print(f"    {i*model.opt.timestep:.1f}s / {duration}s")
    
    print("  Done hovering")

# Mission execution
print("\n" + "="*60)
print("Starting delivery mission...")
print("="*60)

# Phase 1: Takeoff
print("\n[Phase 1/5] Taking off...")
takeoff_target = START_POS + np.array([0, 0, 0.8])
success = fly_to_waypoint(takeoff_target, duration=8.0)
if not success:
    print("⚠ Takeoff had issues but continuing...")

# Phase 2: Fly to pickup
print("\n[Phase 2/5] Flying to pickup location...")
success = fly_to_waypoint(PICKUP_POS, duration=10.0)
if not success:
    print("⚠ Didn't reach pickup exactly but close enough")

# Phase 3: Wait at pickup (simulating package pickup)
print("\n[Phase 3/5] Waiting at pickup (simulating package loading)...")
hover(duration=2.0)

# Phase 4: Fly to dropoff
print("\n[Phase 4/5] Flying to dropoff location...")
success = fly_to_waypoint(DROPOFF_POS, duration=10.0)
if not success:
    print("⚠ Didn't reach dropoff exactly but close enough")

# Phase 5: Land
print("\n[Phase 5/5] Landing...")
success = fly_to_waypoint(LAND_POS, duration=8.0, tolerance=0.2)
if not success:
    print("⚠ Landing not perfect but drone is down")

# Final check
pos, vel = get_drone_state(data)
print("\n" + "="*60)
print("MISSION RESULTS")
print("="*60)
print(f"Final position: ({pos[0]:.3f}, {pos[1]:.3f}, {pos[2]:.3f})")
print(f"Final velocity: ({vel[0]:.3f}, {vel[1]:.3f}, {vel[2]:.3f})")
print(f"Simulation time: {data.time:.1f}s")

# Check success criteria
landed = pos[2] < 0.3  # below 30cm
near_dropoff = np.linalg.norm(pos[:2] - DROPOFF_POS[:2]) < 0.5  # within 50cm horizontally

if landed and near_dropoff:
    print("\n✓ MISSION SUCCESS!")
    print("  - Drone landed safely")
    print("  - Near dropoff location")
else:
    print("\n✗ Mission incomplete")
    if not landed:
        print("  - Drone didn't land properly")
    if not near_dropoff:
        print("  - Drone not at dropoff location")

print("="*60)
print("Done!")

