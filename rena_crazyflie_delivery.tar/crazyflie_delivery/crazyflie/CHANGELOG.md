# Changelog – Bitcraze Crazyflie 2 Description

All notable changes to this model will be documented in this file.

## [2024-03-03]
- Initial release.
